# 🛠️ Installation Guide: Student Records Web Application

This guide describes the full deployment process for the **Student Records Web Application** on AWS using a highly available and scalable architecture. The infrastructure includes VPC, EC2, RDS, Load Balancer, Auto Scaling Group, IAM, and more, as required in the lab assignment.

---

## 📁 1. VPC and Networking Setup

- **Create VPC**
  - CIDR: `10.0.0.0/16`
- **Subnets**
  - Two public subnets in different AZs (e.g. `10.0.1.0/16`, `10.0.2.0/16`)
  - Two private subnets for RDS
- **Internet Gateway**
  - Attach to VPC
- **Route Table**
  - Public route table with default route to IGW
  - Associate it with the public subnets

---

## 🛠️ 2. RDS Database Setup

- **Engine**: MySQL
- **Instance type**: `db.t3.micro` (or `Free Tier`)
- **DB name**: `STUDENTS`
- **Username**: `nodeapp`
- **Password**: `student12`
- **Subnet Group**: Select private subnets
- **VPC Security Group**:
  - Allow port `3306` from EC2 webserver SG only

---

## 🔐 3. Secrets Manager

Create a secret to store DB credentials:

```bash
aws secretsmanager create-secret \
--name Mydbsecret \
--description "Database secret for web app" \
--secret-string '{ "user":"nodeapp", "password":"student12", "host":"<RDS-ENDPOINT>", "db":"STUDENTS" }'
```

---

## 💻 4. EC2 Web Server Setup

- **AMI**: Ubuntu 24.04 LTS
- **Instance Type**: `t3.micro/t2.micro`
- **IAM Role**: `LabRole` (to access Secrets Manager)
- **Security Group**: Allow inbound on port `80` from anywhere

### User Data Script:

```bash
#!/bin/bash -xe
apt update -y
apt install nodejs unzip wget npm mysql-client -y
wget https://aws-tc-largeobjects.s3.us-west-2.amazonaws.com/CUR-TF-200-ACCAP1-1-91571/1-lab-capstone-project-1/code.zip -P /home/ubuntu
cd /home/ubuntu
unzip code.zip -x "resources/codebase_partner/node_modules/*"
cd resources/codebase_partner
npm install aws aws-sdk
export APP_PORT=80
npm start &
```

---

## 📂 5. Data Migration

```bash
mysqldump -h <EC2-DB-IP> -u nodeapp -p --databases STUDENTS > data.sql
mysql -h <RDS-ENDPOINT> -u nodeapp -p < data.sql
```

---

## ⚖️ 6. Load Balancer & Auto Scaling

- **Application Load Balancer**
  - Type: Internet-facing
  - Listener: HTTP (80)
  - Target Group: Register EC2 instances
- **Launch Template**
  - Use previously configured EC2 as base AMI
- **Auto Scaling Group**
  - Min: 2, Max: 4
  - Target Tracking on CPU usage (e.g., 50%)

---

## 🚀 7. Load Testing (Validation)

From Cloud9 or EC2 with `npm`:

```bash
npm install -g loadtest
loadtest --rps 1000 -c 500 -k http://<Your_LOAD_BALANCER_DNS>
```

---



## ✅ Final Notes

- Resources deployed in `us-east-1`
- Monitor billing via AWS Console
- When You Finish Don’t forget to terminate resources Like RDS && EC2 